from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
import shutil
import os
import uuid
import time
from transcriber import Transcriber


app = FastAPI()

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Directories
UPLOAD_DIR = "uploads"
MODELS_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "models")
BACKEND_MODELS_DIR = os.path.join(MODELS_DIR, "backend")

os.makedirs(UPLOAD_DIR, exist_ok=True)

# Transcriber instance (lazy loading handled in class)
transcriber_instances = {}

# Global progress storage
task_progress = {}

# Add NVIDIA library paths to PATH for Windows
if os.name == 'nt':
    try:
        import nvidia
        nvidia_path = list(nvidia.__path__)[0] if nvidia.__path__ else None
        
        if not nvidia_path:
            raise ImportError("Could not find nvidia package path")
        
        # DLLs are typically in 'bin' on Windows for these packages
        nvidia_paths = [
            os.path.join(nvidia_path, 'cublas', 'bin'),
            os.path.join(nvidia_path, 'cudnn', 'bin')
        ]
        
        for path in nvidia_paths:
            if os.path.exists(path) and path not in os.environ['PATH']:
                os.environ['PATH'] = path + os.pathsep + os.environ['PATH']
                print(f"Added to PATH: {path}")
            else:
                if not os.path.exists(path):
                    print(f"Warning: NVIDIA path not found: {path}")
                    
    except ImportError:
        print("NVIDIA libraries not found in python environment. GPU might not work if system libs are missing.")

def get_transcriber(model_size):
    if model_size not in transcriber_instances:
        # Check for CUDA via ctranslate2 (faster-whisper backend)
        import ctranslate2
        device = "cpu"
        compute_type = "int8"
        
        try:
            if ctranslate2.get_cuda_device_count() > 0:
                device = "cuda"
                compute_type = "float16"
                print(f"CUDA device detected. Using {device} with {compute_type}")
            else:
                print("No CUDA device detected. Using CPU.")
        except Exception as e:
            print(f"Error checking CUDA: {e}. Defaulting to CPU.")

        print(f"Initializing Transcriber on {device} with {compute_type}")

        # Check if local model exists
        model_path = os.path.join(BACKEND_MODELS_DIR, model_size)
        if os.path.exists(model_path):
            print(f"Using local model from: {model_path}")
            transcriber_instances[model_size] = Transcriber(model_size=model_size, device=device, compute_type=compute_type, model_path=model_path)
        else:
            print(f"Local model not found at {model_path}, falling back to default download logic (or error if offline)")
            transcriber_instances[model_size] = Transcriber(model_size=model_size, device=device, compute_type=compute_type)
            
    return transcriber_instances[model_size]

@app.post("/transcribe")
def transcribe_video(
    file: UploadFile = File(...),
    model_size: str = Form("tiny"),
    language: str = Form("cs"),
    enable_correction: bool = Form(True),
    diarize: bool = Form(True),
    task_id: str = Form(None)
):
    # Save uploaded file
    file_id = str(uuid.uuid4())
    video_filename = f"{file_id}_{file.filename}"
    video_path = os.path.join(UPLOAD_DIR, video_filename)
    
    try:
        with open(video_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Could not save file: {e}")

    try:
        # Transcribe (handles extraction internally now)
        transcriber = get_transcriber(model_size)
        
        start_time = time.time()
        
        def progress_callback(progress, status="Processing..."):
            if task_id:
                task_progress[task_id] = {
                    "progress": progress,
                    "start_time": start_time,
                    "status": status
                }

        # Pass video path directly
        if task_id:
            progress_callback(0, "Starting transcription...")
            
        segments, info = transcriber.transcribe(video_path, language=language, progress_callback=progress_callback)

        # Diarize
        if task_id and diarize:
            progress_callback(100, "Diarizing...")
            
        # segments are already dicts here
        if diarize:
            segments = transcriber.diarize(video_path, segments)
        else:
            # Ensure speaker field exists even if not diarized
            for seg in segments:
                if "speaker" not in seg:
                    seg["speaker"] = "Speaker"
        
        # Correction
        if task_id and enable_correction:
            progress_callback(100, "Correcting...")
            
            try:
                from corrector import Corrector
                corrector = Corrector()
                for seg in segments:
                    original_text = seg["text"]
                    corrected_text, changes = corrector.correct_segment(original_text, info.language)
                    seg["text"] = corrected_text
                    if changes:
                        seg["changes"] = changes
                        seg["original_text"] = original_text
            except Exception as e:
                print(f"Correction failed: {e}")

        # Cleanup
        if os.path.exists(video_path):
            os.remove(video_path) 
        
        # Cleanup progress
        if task_id and task_id in task_progress:
            del task_progress[task_id] 

        return {
            "language": info.language,
            "duration": info.duration,
            "segments": segments,
            "video_url": f"/uploads/{video_filename}"
        }

    except Exception as e:
        import traceback
        traceback.print_exc()
        if os.path.exists(video_path):
            os.remove(video_path)
        raise HTTPException(status_code=500, detail=f"Server Error: {str(e)}\n{traceback.format_exc()}")

@app.post("/diarize")
async def diarize_audio(
    file: UploadFile = File(...),
    segments: str = Form(...)
):
    import json
    # Save uploaded audio
    file_id = str(uuid.uuid4())
    audio_path = os.path.join(UPLOAD_DIR, f"{file_id}_diarize.wav")

    try:
        with open(audio_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Could not save file: {e}")

    try:
        segments_data = json.loads(segments)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Invalid segments JSON: {e}")

    # Use any transcriber instance for diarization (it's stateless regarding model)
    transcriber = get_transcriber("tiny") 
    
    # Diarize
    segments_data = transcriber.diarize(audio_path, segments_data)

    return segments_data

@app.get("/models")
def get_models():
    return ["medium", "large-v3"]

@app.get("/progress/{task_id}")
def get_progress(task_id: str):
    data = task_progress.get(task_id)
    if not data:
        return {"progress": 0, "eta": None}
        
    if isinstance(data, int): # Backward compatibility or init state
        return {"progress": data, "eta": None}
        
    progress = data["progress"]
    start_time = data["start_time"]
    elapsed = time.time() - start_time
    
    eta = None
    if progress > 0:
        total_estimated = elapsed / (progress / 100.0)
        eta = total_estimated - elapsed
        if eta < 0: eta = 0
        
    return {"progress": progress, "eta": eta, "status": data.get("status", "Processing...")}

# Serve uploads
app.mount("/uploads", StaticFiles(directory=UPLOAD_DIR), name="uploads")

# Serve frontend (must be last)
FRONTEND_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "frontend")
app.mount("/", StaticFiles(directory=FRONTEND_DIR, html=True), name="frontend")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000)
