import torchaudio
print(f"Torchaudio version: {torchaudio.__version__}")
if hasattr(torchaudio, 'list_audio_backends'):
    print("list_audio_backends exists")
else:
    print("list_audio_backends MISSING")
