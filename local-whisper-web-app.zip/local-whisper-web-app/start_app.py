import os
import sys
import subprocess
import webbrowser
import time
from pathlib import Path

def main():
    print("Starting Local Whisper Web App...")
    
    # Get the project root directory
    project_root = Path(__file__).parent.absolute()
    backend_dir = project_root / "backend"
    
    # Ensure we are in the project root
    os.chdir(project_root)

    # Install requirements
    print("Installing requirements...")
    requirements_path = backend_dir / "requirements.txt"
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", str(requirements_path)])
    except subprocess.CalledProcessError as e:
        print(f"Error installing requirements: {e}")
        input("Press Enter to exit...")
        sys.exit(1)

    # Open browser
    print("Opening browser...")
    time.sleep(1) # Give it a moment
    webbrowser.open("http://127.0.0.1:8000")

    # Start Server
    print("Starting Server...")
    server_script = backend_dir / "server.py"
    
    # Run server.py from the backend directory to maintain relative path compatibility (e.g. uploads/)
    try:
        subprocess.run([sys.executable, str(server_script)], cwd=backend_dir)
    except KeyboardInterrupt:
        print("\nServer stopped.")
    except Exception as e:
        print(f"Error running server: {e}")
        input("Press Enter to exit...")

if __name__ == "__main__":
    main()
