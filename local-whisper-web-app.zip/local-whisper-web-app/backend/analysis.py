import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.decomposition import NMF

def extract_topics(text, n_topics=5, n_top_words=3):
    """
    Extracts major topics from the text using NMF on TF-IDF features.
    Returns a list of topic strings (top words for each topic).
    """
    if not text or len(text.split()) < 50:
        return []

    try:
        # Split text into sentences (roughly) for TF-IDF
        # Using simple split by period for simplicity and speed
        sentences = [s.strip() for s in text.split('.') if s.strip()]
        
        if len(sentences) < n_topics:
            n_topics = len(sentences)
            if n_topics == 0:
                return []

        tfidf_vectorizer = TfidfVectorizer(max_df=0.95, min_df=2, stop_words='english')
        tfidf = tfidf_vectorizer.fit_transform(sentences)
        
        # Use NMF for topic modeling
        nmf = NMF(n_components=n_topics, random_state=1, l1_ratio=.5, init='nndsvd').fit(tfidf)
        
        feature_names = tfidf_vectorizer.get_feature_names_out()
        
        topics = []
        for topic_idx, topic in enumerate(nmf.components_):
            top_features_ind = topic.argsort()[:-n_top_words - 1:-1]
            top_features = [feature_names[i] for i in top_features_ind]
            topics.append(" ".join(top_features))
            
        return topics
    except Exception as e:
        print(f"Error extracting topics: {e}")
        return []

def generate_summary(text, n_sentences=3):
    """
    Generates an extractive summary by ranking sentences based on TF-IDF scores.
    """
    if not text:
        return ""
        
    try:
        sentences = [s.strip() for s in text.split('.') if s.strip()]
        if len(sentences) <= n_sentences:
            return text

        tfidf_vectorizer = TfidfVectorizer(stop_words='english')
        tfidf_matrix = tfidf_vectorizer.fit_transform(sentences)
        
        # Sum TF-IDF scores for each sentence
        sentence_scores = np.array(tfidf_matrix.sum(axis=1)).flatten()
        
        # Get top N sentences
        top_sentence_indices = sentence_scores.argsort()[-n_sentences:][::-1]
        top_sentence_indices.sort() # Sort by appearance order
        
        summary = " ".join([sentences[i] for i in top_sentence_indices]) + "."
        return summary
    except Exception as e:
        print(f"Error generating summary: {e}")
        return text[:500] + "..." # Fallback
