import torch
import torchaudio
import speechbrain
import sys

print(f"Python version: {sys.version}")
print(f"Torch version: {torch.__version__}")
print(f"Torchaudio version: {torchaudio.__version__}")
print(f"SpeechBrain version: {speechbrain.__version__}")

try:
    print(f"torchaudio.list_audio_backends available: {hasattr(torchaudio, 'list_audio_backends')}")
except:
    pass
