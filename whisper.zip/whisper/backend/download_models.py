import os
from faster_whisper import download_model

# Define paths
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MODELS_DIR = os.path.join(BASE_DIR, "models")
BACKEND_MODELS_DIR = os.path.join(MODELS_DIR, "backend")

# Ensure directories exist
os.makedirs(BACKEND_MODELS_DIR, exist_ok=True)

def download_backend_models():
    models_to_download = ["medium", "large-v3"]
    
    for model_name in models_to_download:
        print(f"Downloading Backend Model (faster-whisper {model_name})...")
        output_dir = os.path.join(BACKEND_MODELS_DIR, model_name)
        
        if os.path.exists(output_dir):
            print(f"Backend model {model_name} already exists at {output_dir}")
            continue

        print(f"Downloading to {output_dir}...")
        try:
            path = download_model(model_name, output_dir=output_dir)
            print(f"Backend model {model_name} downloaded to: {path}")
        except Exception as e:
            print(f"Failed to download backend model {model_name}: {e}")

if __name__ == "__main__":
    download_backend_models()
    print("Download complete.")
