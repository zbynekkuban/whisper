import torchaudio
print(f"Torchaudio version: {torchaudio.__version__}")
print("Attributes in torchaudio:")
print(dir(torchaudio))
