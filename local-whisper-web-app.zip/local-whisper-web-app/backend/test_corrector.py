import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from corrector import Corrector

def test_corrector():
    c = Corrector()
    
    # Test English
    text = "This is a simle test."
    corrected, changes = c.correct_segment(text, "en")
    print(f"Original: {text}")
    print(f"Corrected: {corrected}")
    print(f"Changes: {changes}")
    assert "simple" in corrected
    assert len(changes) > 0

    # Test Spanish (if dictionary available, otherwise it might skip or use English)
    # pyspellchecker might need internet to download dictionaries first time?
    # Let's see.
    text_es = "Esto es una prueva."
    corrected_es, changes_es = c.correct_segment(text_es, "es")
    print(f"Original: {text_es}")
    print(f"Corrected: {corrected_es}")
    print(f"Changes: {changes_es}")
    # "prueva" -> "prueba"
    
    # Test mixed (English words in Spanish context)
    # Now that we enforce strict language, "world" might be corrected to a Spanish word 
    # or left alone if no good candidate. 
    # We just want to ensure it doesn't crash and uses the Spanish checker.
    text_mixed = "Hola world."
    corrected_mixed, changes_mixed = c.correct_segment(text_mixed, "es")
    print(f"Original: {text_mixed}")
    print(f"Corrected: {corrected_mixed}")
    # "Hola" should be kept. "world" might be corrected or kept.
    assert "Hola" in corrected_mixed

if __name__ == "__main__":
    test_corrector()
