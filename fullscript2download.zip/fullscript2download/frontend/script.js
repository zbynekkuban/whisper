// DOM Elements
const fileInput = document.getElementById('video-upload');
const dropZone = document.getElementById('drop-zone');
const videoPlayer = document.getElementById('main-video');
const uploadPrompt = document.getElementById('upload-prompt');
const modelSelect = document.getElementById('model-select');
const transcribeBtn = document.getElementById('transcribe-btn');
const saveBtn = document.getElementById('save-btn');
const transcriptOutput = document.getElementById('transcript-output');
const loadingOverlay = document.getElementById('loading-overlay');
const loadingText = document.getElementById('loading-text');

const analysisSection = document.getElementById('analysis-section');
const topicsContainer = document.getElementById('topics-container');
const summaryText = document.getElementById('summary-text');

let currentTranscript = [];

// Models list
const MODELS = ["medium", "large-v3"];

// Initialize
function updateModelList() {
    modelSelect.innerHTML = '';
    MODELS.forEach(m => {
        const option = document.createElement('option');
        option.value = m;
        option.textContent = m;
        modelSelect.appendChild(option);
    });
}

updateModelList();

// Drag & Drop
dropZone.addEventListener('dragover', (e) => {
    e.preventDefault();
    dropZone.classList.add('drag-over');
});

dropZone.addEventListener('dragleave', () => {
    dropZone.classList.remove('drag-over');
});

dropZone.addEventListener('drop', (e) => {
    e.preventDefault();
    dropZone.classList.remove('drag-over');
    if (e.dataTransfer.files.length > 0) {
        handleFile(e.dataTransfer.files[0]);
    }
});

dropZone.addEventListener('click', () => fileInput.click());

fileInput.addEventListener('change', (e) => {
    if (e.target.files.length > 0) {
        handleFile(e.target.files[0]);
    }
});

function handleFile(file) {
    if (!file.type.startsWith('video/')) {
        alert("Please upload a video file.");
        return;
    }

    const url = URL.createObjectURL(file);
    videoPlayer.src = url;
    videoPlayer.style.display = 'block';
    uploadPrompt.style.display = 'none';
    transcribeBtn.disabled = false;

    // Hide previous analysis
    analysisSection.classList.add('hidden');

    // Store file for transcription
    fileInput.files = createFileList(file);
}

// Helper to set file input files programmatically
function createFileList(file) {
    const dt = new DataTransfer();
    dt.items.add(file);
    return dt.files;
}

// Transcribe
transcribeBtn.addEventListener('click', async () => {
    const file = fileInput.files[0];
    if (!file) return;

    transcribeBtn.disabled = true;
    saveBtn.disabled = true;
    transcriptOutput.innerHTML = '';
    analysisSection.classList.add('hidden');

    await transcribeServer(file);
});

async function transcribeServer(file) {
    loadingOverlay.classList.remove('hidden');
    loadingText.textContent = "Uploading & Transcribing...";

    const formData = new FormData();
    formData.append('file', file);
    formData.append('model_size', modelSelect.value);

    try {
        const response = await fetch('http://127.0.0.1:8000/transcribe', {
            method: 'POST',
            body: formData
        });

        if (!response.ok) throw new Error('Transcription failed');

        const data = await response.json();
        currentTranscript = data.segments;
        renderTranscript(data.segments);

        if (data.topics && data.summary) {
            renderAnalysis(data.topics, data.summary);
        }

        saveBtn.disabled = false;
    } catch (e) {
        alert(`Error: ${e.message}`);
    } finally {
        loadingOverlay.classList.add('hidden');
        transcribeBtn.disabled = false;
    }
}

function renderAnalysis(topics, summary) {
    topicsContainer.innerHTML = '';
    topics.forEach(topic => {
        const tag = document.createElement('span');
        tag.className = 'topic-tag';
        tag.textContent = topic;
        topicsContainer.appendChild(tag);
    });

    summaryText.textContent = summary;
    analysisSection.classList.remove('hidden');
}

function formatTime(seconds) {
    if (seconds === null || seconds === undefined) return "00:00";
    const date = new Date(seconds * 1000);
    const hh = date.getUTCHours();
    const mm = date.getUTCMinutes();
    const ss = date.getUTCSeconds();
    if (hh) {
        return `${hh}:${mm.toString().padStart(2, '0')}:${ss.toString().padStart(2, '0')}`;
    }
    return `${mm}:${ss.toString().padStart(2, '0')}`;
}

function renderTranscript(segments) {
    transcriptOutput.innerHTML = '';

    segments.forEach(segment => {
        const div = document.createElement('div');
        div.className = 'transcript-segment';
        div.onclick = () => {
            videoPlayer.currentTime = segment.start;
            videoPlayer.play();
        };

        const speakerClass = `speaker-${segment.speaker.replace(/\s+/g, '.')}`;

        div.innerHTML = `
            <div class="segment-meta">
                <span class="speaker ${speakerClass}">${segment.speaker}</span>
                <span class="timestamp">${formatTime(segment.start)} - ${formatTime(segment.end)}</span>
            </div>
            <div class="segment-text">${segment.text}</div>
        `;
        transcriptOutput.appendChild(div);
    });
}

saveBtn.addEventListener('click', () => {
    if (currentTranscript.length === 0) return;

    let textContent = "";
    currentTranscript.forEach(seg => {
        textContent += `[${formatTime(seg.start)} - ${formatTime(seg.end)}] ${seg.speaker}: ${seg.text}\n`;
    });

    const blob = new Blob([textContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'transcript.txt';
    a.click();
    URL.revokeObjectURL(url);
});
