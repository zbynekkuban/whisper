document.addEventListener('DOMContentLoaded', () => {
    // DOM Elements
    const fileInput = document.getElementById('video-upload');
    const dropZone = document.getElementById('drop-zone');
    const videoPlayer = document.getElementById('main-video');
    const uploadPrompt = document.getElementById('upload-prompt');
    const modelSelect = document.getElementById('model-select');
    const languageSelect = document.getElementById('language-select');
    const transcribeBtn = document.getElementById('transcribe-btn');
    const saveBtn = document.getElementById('save-btn');
    const transcriptOutput = document.getElementById('transcript-output');
    const progressContainer = document.getElementById('progress-container');
    const progressFill = document.getElementById('progress-fill');
    const progressText = document.getElementById('progress-text');

    let currentTranscript = [];

    // Models list
    const MODELS = ["medium", "large-v3"];

    // Initialize
    function updateModelList() {
        modelSelect.innerHTML = '';
        MODELS.forEach(m => {
            const option = document.createElement('option');
            option.value = m;
            option.textContent = m;
            modelSelect.appendChild(option);
        });
    }

    updateModelList();

    // Drag & Drop
    dropZone.addEventListener('dragover', (e) => {
        e.preventDefault();
        dropZone.classList.add('drag-over');
    });

    dropZone.addEventListener('dragleave', () => {
        dropZone.classList.remove('drag-over');
    });

    dropZone.addEventListener('drop', (e) => {
        e.preventDefault();
        dropZone.classList.remove('drag-over');
        if (e.dataTransfer.files.length > 0) {
            handleFile(e.dataTransfer.files[0]);
        }
    });

    dropZone.addEventListener('click', () => fileInput.click());

    fileInput.addEventListener('click', (e) => {
        e.stopPropagation();
    });

    fileInput.addEventListener('change', (e) => {
        if (e.target.files.length > 0) {
            handleFile(e.target.files[0]);
        }
    });

    function handleFile(file) {
        if (!file.type.startsWith('video/')) {
            alert("Please upload a video file.");
            return;
        }

        const url = URL.createObjectURL(file);
        videoPlayer.src = url;
        videoPlayer.style.display = 'block';
        uploadPrompt.style.display = 'none';
        transcribeBtn.disabled = false;

        // Store file for transcription
        fileInput.files = createFileList(file);
    }

    // Helper to set file input files programmatically
    function createFileList(file) {
        const dt = new DataTransfer();
        dt.items.add(file);
        return dt.files;
    }

    // Transcribe
    transcribeBtn.addEventListener('click', async () => {
        const file = fileInput.files[0];
        if (!file) return;

        transcribeBtn.disabled = true;
        saveBtn.disabled = true;
        copyBtn.disabled = true;
        transcriptOutput.innerHTML = '';


        await transcribeServer(file);
    });

    function generateUUID() {
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
            var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
            return v.toString(16);
        });
    }

    async function transcribeServer(file) {
        // Reset progress
        progressFill.style.width = '0%';
        progressText.textContent = '0%';
        progressContainer.classList.remove('hidden');

        const taskId = generateUUID();
        const formData = new FormData();
        formData.append('file', file);
        formData.append('model_size', modelSelect.value);
        formData.append('language', languageSelect.value);
        formData.append('enable_correction', document.getElementById('correction-toggle').checked);
        formData.append('diarize', document.getElementById('diarize-toggle').checked);
        formData.append('task_id', taskId);

        // Start polling
        const pollInterval = setInterval(async () => {
            try {
                const res = await fetch(`http://127.0.0.1:8000/progress/${taskId}`);
                if (res.ok) {
                    const data = await res.json();
                    const progress = data.progress;
                    const status = data.status || "Processing...";

                    progressFill.style.width = `${progress}%`;

                    let text = `${status} (${progress}%)`;
                    if (data.eta !== null && data.eta !== undefined) {
                        const etaSeconds = Math.round(data.eta);
                        text += ` - ETA: ${formatTime(etaSeconds)}`;
                    }
                    progressText.textContent = text;

                    // Update title
                    document.title = `(${progress}%) ${status} - Local Whisper`;
                }
            } catch (e) {
                console.error("Polling error", e);
            }
        }, 1000);

        try {
            const response = await fetch('http://127.0.0.1:8000/transcribe', {
                method: 'POST',
                body: formData
            });

            clearInterval(pollInterval);
            progressFill.style.width = '100%';
            progressText.textContent = '100%';

            if (!response.ok) {
                const errData = await response.json();
                throw new Error(errData.detail || 'Transcription failed');
            }

            const data = await response.json();
            currentTranscript = data.segments;
            renderTranscript(data.segments);

            saveBtn.disabled = false;
            copyBtn.disabled = false;
        } catch (e) {
            clearInterval(pollInterval);
            alert(`Error: ${e.message}`);
        } finally {
            progressContainer.classList.add('hidden');
            transcribeBtn.disabled = false;
            document.title = "Local Whisper Transcriber";
        }
    }

    function formatTime(seconds) {
        if (seconds === null || seconds === undefined) return "00:00";
        const date = new Date(seconds * 1000);
        const hh = date.getUTCHours();
        const mm = date.getUTCMinutes();
        const ss = date.getUTCSeconds();
        if (hh) {
            return `${hh}:${mm.toString().padStart(2, '0')}:${ss.toString().padStart(2, '0')}`;
        }
        return `${mm}:${ss.toString().padStart(2, '0')}`;
    }

    function renderTranscript(segments) {
        transcriptOutput.innerHTML = '';

        const showSpeakers = document.getElementById('show-speakers-toggle').checked;

        segments.forEach(segment => {
            const div = document.createElement('div');
            div.className = 'transcript-segment';
            div.onclick = () => {
                videoPlayer.currentTime = segment.start;
            };

            const speakerClass = `speaker-${segment.speaker.replace(/\s+/g, '-')}`;

            let segmentHtml = segment.text;
            if (segment.changes && segment.changes.length > 0) {
                // ... (correction highlighting logic remains same) ...
                segment.changes.sort((a, b) => a.start - b.start);
                let lastIndex = 0;
                let newHtml = "";
                segment.changes.forEach(change => {
                    newHtml += segment.text.substring(lastIndex, change.start);
                    newHtml += `<span class="corrected" title="Original: ${change.original}">${change.new}</span>`;
                    lastIndex = change.end;
                });
                newHtml += segment.text.substring(lastIndex);
                segmentHtml = newHtml;
            }

            const speakerDisplay = showSpeakers ? `<span class="speaker ${speakerClass}">${segment.speaker}</span>` : '';

            div.innerHTML = `
                <div class="segment-meta">
                    ${speakerDisplay}
                    <span class="timestamp">${formatTime(segment.start)} - ${formatTime(segment.end)}</span>
                </div>
                <div class="segment-text">${segmentHtml}</div>
            `;
            transcriptOutput.appendChild(div);
        });
    }

    document.getElementById('show-speakers-toggle').addEventListener('change', () => {
        if (currentTranscript.length > 0) {
            renderTranscript(currentTranscript);
        }
    });

    const diarizeToggle = document.getElementById('diarize-toggle');
    const showSpeakersToggle = document.getElementById('show-speakers-toggle');

    function updateShowSpeakersState() {
        if (diarizeToggle.checked) {
            showSpeakersToggle.disabled = false;
        } else {
            showSpeakersToggle.disabled = true;
            showSpeakersToggle.checked = false;
            // Update view if we have a transcript
            if (currentTranscript.length > 0) {
                renderTranscript(currentTranscript);
            }
        }
    }

    diarizeToggle.addEventListener('change', updateShowSpeakersState);
    // Initialize state
    updateShowSpeakersState();

    const copyBtn = document.getElementById('copy-btn');

    function getTranscriptText(onlyText = false) {
        if (currentTranscript.length === 0) return "";

        const showSpeakers = document.getElementById('show-speakers-toggle').checked;
        let textContent = "";

        currentTranscript.forEach(seg => {
            if (onlyText) {
                textContent += `${seg.text}\n`;
            } else {
                if (showSpeakers) {
                    textContent += `[${formatTime(seg.start)} - ${formatTime(seg.end)}] ${seg.speaker}: ${seg.text}\n`;
                } else {
                    textContent += `[${formatTime(seg.start)} - ${formatTime(seg.end)}] ${seg.text}\n`;
                }
            }
        });
        return textContent;
    }

    copyBtn.addEventListener('click', async () => {
        const text = getTranscriptText(true);
        if (!text) return;

        try {
            await navigator.clipboard.writeText(text);
            const originalText = copyBtn.textContent;
            copyBtn.textContent = "Copied!";
            setTimeout(() => {
                copyBtn.textContent = originalText;
            }, 2000);
        } catch (err) {
            console.error('Failed to copy: ', err);
            alert("Failed to copy to clipboard");
        }
    });

    saveBtn.addEventListener('click', () => {
        const textContent = getTranscriptText();
        if (!textContent) return;

        const blob = new Blob([textContent], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'transcript.txt';
        a.click();
        URL.revokeObjectURL(url);
    });
});
