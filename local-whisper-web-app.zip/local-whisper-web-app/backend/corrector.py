import re
from spellchecker import SpellChecker
import logging

logger = logging.getLogger(__name__)

class Corrector:
    def __init__(self):
        self.spellcheckers = {}
        # Map Whisper language codes to pyspellchecker codes where possible
        self.lang_map = {
            "en": "en",
            "es": "es",
            "de": "de",
            "fr": "fr",
            "pt": "pt",
            "ar": "ar"
        }

    def get_spellchecker(self, lang_code):
        # Use only the detected language
        target_lang = self.lang_map.get(lang_code)
        
        if not target_lang:
            # If language not supported by pyspellchecker, return None
            return None
            
        key = target_lang
        
        if key not in self.spellcheckers:
            logger.info(f"Loading spellchecker for language: {target_lang}")
            try:
                self.spellcheckers[key] = SpellChecker(language=target_lang)
            except Exception as e:
                logger.error(f"Failed to load spellchecker for {target_lang}: {e}")
                self.spellcheckers[key] = None
                
        return self.spellcheckers[key]

    def correct_segment(self, text, lang_code="en"):
        if not text:
            return text, []

        checker = self.get_spellchecker(lang_code)
        if not checker:
            return text, []

        # Tokenize (keep punctuation)
        tokens = re.split(r'(\W+)', text)
        
        corrected_tokens = []
        changes = []
        
        current_pos = 0
        
        for token in tokens:
            if not token.strip() or not token.isalpha():
                corrected_tokens.append(token)
                current_pos += len(token)
                continue
                
            # Check if known
            if checker.known([token]):
                corrected_tokens.append(token)
                current_pos += len(token)
            else:
                # Unknown word. Try to correct.
                correction = checker.correction(token)
                
                if correction and correction != token:
                    corrected_tokens.append(correction)
                    changes.append({
                        "start": current_pos,
                        "end": current_pos + len(correction),
                        "original": token,
                        "new": correction
                    })
                    current_pos += len(correction)
                else:
                    corrected_tokens.append(token)
                    current_pos += len(token)

        corrected_text = "".join(corrected_tokens)
        return corrected_text, changes
