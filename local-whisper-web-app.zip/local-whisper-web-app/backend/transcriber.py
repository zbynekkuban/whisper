import os
import logging
from faster_whisper import WhisperModel
import numpy as np
from sklearn.cluster import AgglomerativeClustering
import librosa
import av

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class Transcriber:
    def __init__(self, model_size="tiny", device="cpu", compute_type="int8", model_path=None):
        self.model_size = model_size
        self.device = device
        self.compute_type = compute_type
        self.model_path = model_path
        self.model = None

    def load_model(self):
        if self.model is None:
            model_to_load = self.model_path if self.model_path else self.model_size
            logger.info(f"Loading Whisper model: {model_to_load} on {self.device} with {self.compute_type}")
            try:
                self.model = WhisperModel(model_to_load, device=self.device, compute_type=self.compute_type)
            except Exception as e:
                logger.error(f"Failed to load model on {self.device}: {e}")
                if self.device == "cuda":
                    logger.info("Falling back to CPU...")
                    self.device = "cpu"
                    self.compute_type = "int8"
                    self.model = WhisperModel(model_to_load, device=self.device, compute_type=self.compute_type)
                else:
                    raise e

    def extract_audio(self, video_path):
        """
        Extracts audio from video using PyAV and returns it as a numpy array (16kHz mono).
        """
        logger.info(f"Extracting audio from {video_path}")
        try:
            with av.open(video_path) as container:
                audio_stream = next((s for s in container.streams if s.type == 'audio'), None)
                
                if not audio_stream:
                    raise ValueError("No audio stream found")

                resampler = av.AudioResampler(format='s16', layout='mono', rate=16000)
                
                audio_data = []
                for frame in container.decode(audio_stream):
                    frame.pts = None # Avoid warning
                    resampled_frames = resampler.resample(frame)
                    for r_frame in resampled_frames:
                        audio_data.append(r_frame.to_ndarray())

            if not audio_data:
                return None

            # Concatenate and normalize
            # audio_data is a list of (1, samples) arrays. Concatenate along time axis (1).
            audio_np = np.concatenate(audio_data, axis=1)
            # Convert s16 to float32 [-1, 1]
            audio_float = audio_np.astype(np.float32) / 32768.0
            
            return audio_float.flatten()
            
        except Exception as e:
            logger.error(f"Error extracting audio with PyAV: {e}")
            return None

    def transcribe(self, audio_input, language=None, progress_callback=None):
        self.load_model()
        
        if progress_callback:
            progress_callback(0, "Extracting audio...")

        audio_data = None
        if isinstance(audio_input, str):
            logger.info(f"Transcribing file: {audio_input}")
            # If it's a file path, we can let faster-whisper handle it directly OR extract it ourselves.
            # faster-whisper uses ffmpeg internally if we pass a path.
            # To strictly avoid external ffmpeg binary dependency, we should extract using PyAV first.
            audio_data = self.extract_audio(audio_input)
            if audio_data is None:
                raise ValueError("Could not extract audio")
        else:
            logger.info("Transcribing numpy array...")
            audio_data = audio_input

        if progress_callback:
            progress_callback(0, "Transcribing...")

        segments, info = self.model.transcribe(audio_data, beam_size=5, language=language)
        total_duration = info.duration
        
        result_segments = []
        for segment in segments:
            if progress_callback and total_duration > 0:
                progress = min(100, int(segment.end / total_duration * 100))
                progress_callback(progress, "Transcribing...")
                
            result_segments.append({
                "start": segment.start,
                "end": segment.end,
                "text": segment.text,
                "speaker": "Unknown" # Placeholder, will be updated by diarization
            })
        
        if progress_callback:
            progress_callback(100, "Completed")
            
        return result_segments, info

    def diarize(self, audio_input, segments, num_speakers=2):
        logger.info("Starting diarization with SpeechBrain...")
        try:
            import torch
            import torchaudio
            
            # Monkeypatch for newer torchaudio versions (2.9.1+) where list_audio_backends might be missing/moved
            if not hasattr(torchaudio, 'list_audio_backends'):
                logger.info("Monkeypatching torchaudio.list_audio_backends...")
                torchaudio.list_audio_backends = lambda: ['soundfile']

            from speechbrain.pretrained import EncoderClassifier
            
            # Load classifier (will download to cache on first run)
            # Use cpu for embedding extraction to avoid VRAM OOM if whisper is loaded on GPU
            # or use same device if we have plenty of VRAM.
            # IMPORTANT: Check if torch actually supports CUDA before requesting it, 
            # even if self.device is 'cuda' (which might be for ctranslate2 only).
            use_cuda = (self.device == "cuda" and torch.cuda.is_available())
            run_opts = {"device": "cuda"} if use_cuda else {"device": "cpu"}
            
            classifier = EncoderClassifier.from_hparams(
                source="speechbrain/spkrec-ecapa-voxceleb", 
                savedir="pretrained_models/spkrec-ecapa-voxceleb", 
                run_opts=run_opts
            )
            
            y = None
            sr = 16000
            
            if isinstance(audio_input, str):
                # Load audio using PyAV if it's a path
                y = self.extract_audio(audio_input)
            else:
                y = audio_input
                
            if y is None:
                raise ValueError("No audio data for diarization")
            
            # Extract features for each segment
            segment_embeddings = []
            valid_segments_indices = []

            for i, seg in enumerate(segments):
                # Handle both object (server-side) and dict (client-side) segments
                if isinstance(seg, dict):
                    start = seg["start"]
                    end = seg["end"]
                else:
                    start = seg.start
                    end = seg.end

                start_sample = int(start * sr)
                end_sample = int(end * sr)
                
                if end_sample > len(y):
                    end_sample = len(y)
                
                if end_sample - start_sample < 1600: # Skip very short segments (<0.1s)
                    continue

                segment_audio = y[start_sample:end_sample]
                
                # Convert to tensor
                signal = torch.tensor(segment_audio).unsqueeze(0)
                if use_cuda:
                    signal = signal.to("cuda")

                # Extract embedding
                embeddings = classifier.encode_batch(signal)
                # embeddings shape: [1, 1, 192] -> flatten to [192]
                emb = embeddings.squeeze().cpu().numpy()
                
                segment_embeddings.append(emb)
                valid_segments_indices.append(i)

            if not segment_embeddings:
                logger.warning("No valid segments for diarization.")
                return segments

            # Cluster
            X = np.array(segment_embeddings)
            # Use cosine distance for embeddings
            clustering = AgglomerativeClustering(
                n_clusters=None, 
                metric="cosine", 
                linkage="average",
                distance_threshold=0.5 # Tunable threshold for speaker similarity
            ).fit(X)
            labels = clustering.labels_
            
            # Assign labels back to segments
            for idx, label in zip(valid_segments_indices, labels):
                if isinstance(segments[idx], dict):
                    segments[idx]["speaker"] = f"Speaker {label + 1}"
                else:
                    pass 
            
            # Fill in missing speakers (too short segments) with previous speaker
            current_speaker = "Speaker 1"
            for seg in segments:
                if isinstance(seg, dict):
                    if seg.get("speaker") == "Unknown":
                        seg["speaker"] = current_speaker
                    else:
                        current_speaker = seg["speaker"]

            return segments

        except Exception as e:
            logger.error(f"Diarization failed: {e}")
            import traceback
            traceback.print_exc()
            return segments
